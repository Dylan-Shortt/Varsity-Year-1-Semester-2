package ice.pkg4;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class Gif {

    public static void playGif(String gifPath) {

        // Create a JFrame
        JFrame frame = new JFrame("GIF Player");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load the GIF from the classpath
        URL gifUrl = Gif.class.getResource(gifPath);
        if (gifUrl != null) {
            ImageIcon icon = new ImageIcon(gifUrl);

            // Scale the GIF to fit the screen size
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Image scaledImage = icon.getImage().getScaledInstance(screenSize.width, screenSize.height, Image.SCALE_DEFAULT);
            ImageIcon scaledIcon = new ImageIcon(scaledImage);

            JLabel label = new JLabel(scaledIcon);

            // Set the JFrame to full screen
            frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            frame.setUndecorated(true);

            // Add the JLabel containing the GIF to the JFrame
            frame.getContentPane().add(label, BorderLayout.CENTER);

            // Make the JFrame visible
            frame.pack();
            frame.setVisible(true);
            
            try {
                // Create an instance of the Audio class and play the sound
                Audio audio = new Audio("Hippo01.wav");

                
                // Use a separate thread to handle the wait
                ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
                executorService.schedule(() -> {
                // Code to execute after the wait
                System.exit(0);
            
                }, 215, TimeUnit.SECONDS); // 5-second wait

                executorService.shutdown();
                
                // Stop and close the audio
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                e.printStackTrace();
            }

        } else {
            System.out.println("GIF file not found! Path used: " + gifPath);
        }
    }
}
