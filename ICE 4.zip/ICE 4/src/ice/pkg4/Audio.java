package ice.pkg4;

// Import necessary libraries for audio handling
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

//*************************************************//
// Audio class to manage audio playback
//*************************************************//
public class Audio {

    //*************************************************//
    // Instance variables for Clip and AudioInputStream
    Clip clip;
    AudioInputStream audioInputStream;
    //*************************************************//

    // Constructor to initialize and play the sound file
    public Audio(String filePath)
            throws UnsupportedAudioFileException, IOException, LineUnavailableException {
        //*************************************************//
        // Create AudioInputStream object from the file path
        audioInputStream = AudioSystem.getAudioInputStream(new File(filePath).getAbsoluteFile());
        //*************************************************//

        //*************************************************//
        // Create a Clip object and open the AudioInputStream
        clip = AudioSystem.getClip();
        clip.open(audioInputStream);
        //*************************************************//

        //*************************************************//
        // Start playing the clip
        clip.start();
        //*************************************************//
        
    }

    //*************************************************//
    // Method to stop the currently playing audio
    public void stop() {
        //*************************************************//
        // Check if the clip is playing
        if (clip.isRunning()) {
            // Stop the clip if it is currently running
            clip.stop();
        }
        //*************************************************//

        //*************************************************//
        // Close the clip and release resources
        clip.stop();
        clip.close();
        //*************************************************//
        
        //*************************************************//
        // Optionally, you can also close the AudioInputStream
        // This is useful to ensure no resources are held
        try {
            audioInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //*************************************************//
    }
    //*************************************************//
}
//*************************************************End of file*************************************************//
