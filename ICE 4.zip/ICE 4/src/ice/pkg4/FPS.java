package ice.pkg4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.AffineTransform;

public class FPS extends JPanel implements KeyListener, Runnable {
    private final int nScreenWidth = 1200;
    private final int nScreenHeight = 700;
    private final int nMapWidth = 16;
    private final int nMapHeight = 16;
    private final float fFOV = (float) (Math.PI / 4.0);
    private final float fDepth = 16.0f;
    private final float fSpeed = 5.0f;

    private float fPlayerX = 1.5f; // Starting position
    private float fPlayerY = 1.5f;
    private float fPlayerA = 0.0f;

    private boolean[] keys = new boolean[4]; // W, A, S, D
    private String map;

    private enum GameState { STARTUP, IN_GAME, CONGRATS }
    private GameState gameState = GameState.STARTUP;

    private float fEndX;
    private float fEndY;
    
    public FPS() {
        setPreferredSize(new Dimension(nScreenWidth, nScreenHeight));
        setFocusable(true);
        addKeyListener(this);

        // Create Map with Start (S) and End (E)
        map = "S.......#.......";
        map += "#...............";
        map += "#.......########";
        map += "#..............#";
        map += "#......##......#";
        map += "#......##......#";
        map += "#..............#";
        map += "###............#";
        map += "##.............#";
        map += "#......####..###";
        map += "#......#.......#";
        map += "#......#.......#";
        map += "#..............#";
        map += "#......#########";
        map += "#..............E";
        map += "################";

        // Find end point location
        findEndPoint();
    }

    private void findEndPoint() {
        for (int y = 0; y < nMapHeight; y++) {
            for (int x = 0; x < nMapWidth; x++) {
                if (map.charAt(y * nMapWidth + x) == 'E') {
                    fEndX = x + 0.5f;
                    fEndY = y + 0.5f;
                    return; // End point found, no need to search further
                }
            }
        }
        // Default to a position if 'E' is not found
        fEndX = nMapWidth - 1.5f;
        fEndY = nMapHeight - 1.5f;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (gameState == GameState.STARTUP) {
            drawStartupScreen(g);
        } else if (gameState == GameState.IN_GAME) {
            drawGame(g);
            drawMap(g);
        }
    }

    private void drawStartupScreen(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, nScreenWidth, nScreenHeight);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 36));
        g.drawString("Bullet Storm", nScreenWidth / 2 - 100, nScreenHeight / 2 - 50);
        g.setFont(new Font("Arial", Font.PLAIN, 24));
        g.drawString("Press ENTER to Start", nScreenWidth / 2 - 130, nScreenHeight / 2);
    }

    private void drawGame(Graphics g) {
    // Clear screen with red sky color
    g.setColor(Color.RED); // Red sky color
    g.fillRect(0, 0, nScreenWidth, nScreenHeight);

    // Draw the map
    drawMap(g);

    // Draw Player as an Arrow pointing in the direction of movement
    drawPlayerArrow(g, fPlayerX, fPlayerY, fPlayerA);

    // Perform raycasting for 3D effect
    for (int x = 0; x < nScreenWidth; x++) {
        float fRayAngle = (fPlayerA - fFOV / 2.0f) + ((float) x / nScreenWidth) * fFOV;
        float fStepSize = 0.1f;
        float fDistanceToWall = 0.0f;
        boolean bHitWall = false;
        float fEyeX = (float) Math.sin(fRayAngle);
        float fEyeY = (float) Math.cos(fRayAngle);

        while (!bHitWall && fDistanceToWall < fDepth) {
            fDistanceToWall += fStepSize;
            int nTestX = (int) (fPlayerX + fEyeX * fDistanceToWall);
            int nTestY = (int) (fPlayerY + fEyeY * fDistanceToWall);

            if (nTestX < 0 || nTestX >= nMapWidth || nTestY < 0 || nTestY >= nMapHeight) {
                bHitWall = true;
                fDistanceToWall = fDepth;
            } else {
                if (map.charAt(nTestY * nMapWidth + nTestX) == '#') {
                    bHitWall = true;
                }
            }
        }

        // Calculate column height and draw
        int nCeiling = (int) ((nScreenHeight / 2.0) - nScreenHeight / ((float) fDistanceToWall));
        int nFloor = nScreenHeight - nCeiling;

        for (int y = 0; y < nScreenHeight; y++) {
            if (y < nCeiling) {
                g.setColor(Color.RED); // Red sky color
            } else if (y > nCeiling && y <= nFloor) {
                g.setColor(Color.GRAY); // Gray floor color
            } else {
                g.setColor(Color.RED); // Red sky color
            }
            g.drawLine(x, y, x, y);
        }
    }

    // Check if player reached the endpoint
    if (Math.abs(fPlayerX - fEndX) < 0.5 && Math.abs(fPlayerY - fEndY) < 0.5) {
        gameState = GameState.CONGRATS;
        // Call Gif.playGif() method
        Gif.playGif("/Mr_Hippo.gif");               
    }
}

    private void drawMap(Graphics g) {
        int tileSize = 12; // Reduced size of each tile
        int mapOffsetX = 10; // Offset from the left
        int mapOffsetY = 10; // Offset from the top

        for (int x = 0; x < nMapWidth; x++) {
            for (int y = 0; y < nMapHeight; y++) {
                char tile = map.charAt(y * nMapWidth + x);
                Color color;
                switch (tile) {
                    case '#':
                        color = Color.BLACK; // Black walls color
                        break;
                    case 'S':
                        color = Color.GREEN; // Start color
                        break;
                    case 'E':
                        color = Color.RED; // End color
                        break;
                    default:
                        color = Color.WHITE; // Empty tile color
                        break;
                }
                g.setColor(color);
                g.fillRect(mapOffsetX + x * tileSize, mapOffsetY + y * tileSize, tileSize, tileSize); // Draw the tile
            }
        }

        // Draw the player's position on the map
        int playerTileSize = 6; // Size of the player indicator on the map
        int playerXMap = (int) (fPlayerX);
        int playerYMap = (int) (fPlayerY);
        g.setColor(Color.BLUE);
        g.fillRect(mapOffsetX + playerXMap * tileSize + (tileSize - playerTileSize) / 2,
                   mapOffsetY + playerYMap * tileSize + (tileSize - playerTileSize) / 2,
                   playerTileSize, playerTileSize); // Draw the player indicator
    }

    private void drawPlayerArrow(Graphics g, float x, float y, float angle) {
        Graphics2D g2d = (Graphics2D) g;
        int arrowSize = 20;

        Polygon arrow = new Polygon();
        arrow.addPoint(0, -arrowSize);
        arrow.addPoint(-arrowSize / 2, arrowSize / 2);
        arrow.addPoint(arrowSize / 2, arrowSize / 2);

        AffineTransform transform = new AffineTransform();
        transform.translate(x * 40 + 20, y * 40 + 20); // Adjust center position
        transform.rotate(angle);

        Shape transformedArrow = transform.createTransformedShape(arrow);
        g2d.setColor(Color.BLUE);
        g2d.fill(transformedArrow);
    }

    public void updateGame(float fElapsedTime) {
        if (keys[0]) { // W key for forward movement
            float newPlayerX = fPlayerX + (float) Math.sin(fPlayerA) * fSpeed * fElapsedTime;
            float newPlayerY = fPlayerY + (float) Math.cos(fPlayerA) * fSpeed * fElapsedTime;

            if (map.charAt(((int) newPlayerY) * nMapWidth + (int) newPlayerX) != '#') {
                fPlayerX = newPlayerX;
                fPlayerY = newPlayerY;
            }
        }

        if (keys[1]) { // A key for turning left
            fPlayerA -= 2.0f * fElapsedTime;
        }

        if (keys[2]) { // S key for backward movement
            float newPlayerX = fPlayerX - (float) Math.sin(fPlayerA) * fSpeed * fElapsedTime;
            float newPlayerY = fPlayerY - (float) Math.cos(fPlayerA) * fSpeed * fElapsedTime;

            if (map.charAt(((int) newPlayerY) * nMapWidth + (int) newPlayerX) != '#') {
                fPlayerX = newPlayerX;
                fPlayerY = newPlayerY;
            }
        }

        if (keys[3]) { // D key for turning right
            fPlayerA += 2.0f * fElapsedTime;
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W:
                keys[0] = true;
                break;
            case KeyEvent.VK_A:
                keys[1] = true;
                break;
            case KeyEvent.VK_S:
                keys[2] = true;
                break;
            case KeyEvent.VK_D:
                keys[3] = true;
                break;
            case KeyEvent.VK_ENTER:
                if (gameState == GameState.STARTUP) {
                    gameState = GameState.IN_GAME;
                    new Thread(this).start();
                }
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W:
                keys[0] = false;
                break;
            case KeyEvent.VK_A:
                keys[1] = false;
                break;
            case KeyEvent.VK_S:
                keys[2] = false;
                break;
            case KeyEvent.VK_D:
                keys[3] = false;
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void run() {
        long lastTime = System.nanoTime();
        final double nsPerTick = 1_000_000_000.0 / 60.0; // 60 FPS
        double delta = 0.0;

        while (gameState == GameState.IN_GAME) {
            long now = System.nanoTime();
            delta += (now - lastTime) / nsPerTick;
            lastTime = now;

            while (delta >= 1) {
                updateGame(1.0f / 60.0f);
                repaint();
                delta--;
            }

            try {
                Thread.sleep(2); // Sleep to avoid high CPU usage
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public static void startGame() {
    FPS game = new FPS();
    JFrame frame = new JFrame("BULLET_STORM");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setContentPane(game);
    frame.pack();
    frame.setResizable(false);

    // Set JFrame to fit the screen size
    Toolkit toolkit = Toolkit.getDefaultToolkit();
    Dimension screenSize = toolkit.getScreenSize();
    frame.setSize(screenSize.width, screenSize.height);

    frame.setVisible(true);
}
}
