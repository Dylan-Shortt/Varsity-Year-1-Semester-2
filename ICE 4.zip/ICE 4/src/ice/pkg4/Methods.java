/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//*************************************************//
package ice.pkg4;
//*************************************************//
/**
 *
 * @author dylan
 */
//*************************************************//
public class Methods {
    
    //*************************************************//
     //wait for a set ammount of seconds
    public void waitFor(int seconds) {
        //*************************************************//
        try {
            // Convert seconds to milliseconds
            int milliseconds = seconds * 1000;
            // Pause the execution for the specified time
            Thread.sleep(milliseconds);
        } 
        //*************************************************//
        
        //*************************************************//
        catch (InterruptedException e) {
            // Handle the case where the sleep was interrupted
            Thread.currentThread().interrupt();
            System.err.println("The wait was interrupted.");
        }
        //*************************************************//
    }
    //*************************************************//
    
    //*************************************************//
    //Check strings contain values
    public boolean loginClass(String username, String password)
    {
        //*************************************************//
        //return false if_ they contain values
        if((username.isBlank() || password.isBlank()))
        {
            return false;
        }
        //*************************************************//
        
        //*************************************************//
        //else
        return true;
        //*************************************************//
    }
    //*************************************************//
    
}
//***********************************END OF FILE****************************************//