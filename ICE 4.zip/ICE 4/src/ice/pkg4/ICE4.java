/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
//*************************************************//
package ice.pkg4;
//*************************************************//

/**
 *
 * @author dylan
 */
//*************************************************//
public class ICE4 {

    /**
     * @param args the command line arguments
     */
    //*************************************************//
    public static void main(String[] args) {
            // TODO code application logic here
            
            //*************************************************//
            //import and create an instance of TextToSpeech class && ICE_4_methods
            TextToSpeech speech = new TextToSpeech();
            Methods methods = new Methods();
            Title_Screen title_screen = new Title_Screen();
            //*************************************************//
           
            //*************************************************//
            //play outro sequence 
            speech.textToSpeech("...Disclaimer: I do not claim ownership of any content used in this project... ...");
            //*************************************************//
            
            //*************************************************//
            //welcome the user
            speech.textToSpeech("... ... ... Welcome player ... to our new world... called... Call Of... hold on,... wait a minute,... something isn't right...?");
            speech.textToSpeech("... we don't have the rights to that name do we ..?");
            speech.textToSpeech("... we will have to come up with something else...");
            speech.textToSpeech("... welcome to the new world of Halo in... wait we can't use that either can we...");
            speech.textToSpeech("... one last try...");
            speech.textToSpeech("... ... ... Welcome player to our new world ... called... Bullet Storm");
            //*************************************************//
            
            //*************************************************//
            //wait 5 seconds then show a image for the game
            methods.waitFor(1);
            title_screen.setVisible(true);
            methods.waitFor(5);
            title_screen.dispose();
            //*************************************************//
            
            //*************************************************//
            //open login screen
             Game login = new Game();
             login.setVisible(true);
            //*************************************************//
            
    }
    //*************************************************//
    
}
//*************************************************End of file*************************************************//